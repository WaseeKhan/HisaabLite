package com.expygen.controller;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.expygen.entity.EmailVerificationToken;
import com.expygen.entity.User;
import com.expygen.repository.EmailVerificationTokenRepository;
import com.expygen.repository.UserRepository;
import com.expygen.service.WorkspaceAccessService;
import com.expygen.service.WorkspaceAccessState;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class VerificationController {

    private final EmailVerificationTokenRepository tokenRepository;
    private final UserRepository userRepository;
    private final WorkspaceAccessService workspaceAccessService;

    @GetMapping("/verify")
    public String verifyAccount(@RequestParam String token, Model model, HttpServletResponse response) {

        Optional<EmailVerificationToken> tokenOpt =
                Optional.ofNullable(tokenRepository.findByToken(token));

        if (tokenOpt.isEmpty() ||
                tokenOpt.get().getExpiryDate().isBefore(LocalDateTime.now())) {

            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            model.addAttribute("message", "This verification link is invalid or has expired.");
            return "error/404";
        }

        EmailVerificationToken verificationToken = tokenOpt.get();

        User user = verificationToken.getUser();
        user.setActive(true);

        userRepository.save(user);

        tokenRepository.delete(verificationToken);

        model.addAttribute("message", "Account verified successfully. Please login.");

        WorkspaceAccessState accessState = workspaceAccessService.getAccessState(user);
        if (accessState == WorkspaceAccessState.APPROVAL_PENDING) {
            return "redirect:/login?verified=pending";
        }

        return "redirect:/login?verified=active";
    }
}
